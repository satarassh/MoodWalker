/** Automatically generated file. DO NOT MODIFY */
package org.naspletu.querybywalking;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}