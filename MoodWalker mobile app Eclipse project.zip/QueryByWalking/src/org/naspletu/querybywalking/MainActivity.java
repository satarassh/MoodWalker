package org.naspletu.querybywalking;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {
	private SensorManager senSensorManager;
    private Sensor senAccelerometer;
    
    private Timer timer;
    
	public TextView textViewCount;
	public TextView textViewBpm;
	public TextView textViewStatus;
	public TextView textViewInfo;
	public Spinner spinnerMode;
	
	public int musicMode = 0;
	
	private float   mLimit = 10.00f; // 1.97  2.96  4.44  6.66  10.00(default)  15.00  22.50  33.75  50.62
    private float   mLastValues[] = new float[3*2];
    private float   mScale[] = new float[2];
    private float   mYOffset;

    private float   mLastDirections[] = new float[3*2];
    private float   mLastExtremes[][] = { new float[3*2], new float[3*2] };
    private float   mLastDiff[] = new float[3*2];
    private int     mLastMatch = -1;
    
    private final int bufferSize = 5;
    private int mCount = 0;
    private int lastCount = 0;
    private int[] buffer = new int[bufferSize];
    private int firstCounts = 0;
    
    //UDP Controllers
    private int udpPort = 2000;
    private DatagramSocket udpSocket;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		senSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        senAccelerometer = senSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        senSensorManager.registerListener(this, senAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        //senOrientation = senSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        //senSensorManager.registerListener(this, senOrientation, SensorManager.SENSOR_DELAY_FASTEST);
		
		textViewCount = (TextView) findViewById(R.id.textViewCount);
		textViewBpm = (TextView) findViewById(R.id.textViewBpm);
		textViewStatus = (TextView) findViewById(R.id.textViewStatus);
		textViewInfo = (TextView) findViewById(R.id.textViewInfo);
		spinnerMode = (Spinner) findViewById(R.id.spinnerMode);
		
		spinnerMode.setOnItemSelectedListener(new OnItemSelectedListener() {
		    @Override
		    public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
		    	musicMode = position;
		        if(position == 0) {
		        	textViewInfo.setText(R.string.info_queue);
		        } else if(position == 1) {
		        	textViewInfo.setText(R.string.info_penta);
		        } else if(position == 2) {
		        	textViewInfo.setText(R.string.info_blues);
		        } else if(position == 3) {
		        	textViewInfo.setText(R.string.info_piano);
		        }
		    }

		    @Override
		    public void onNothingSelected(AdapterView<?> parentView) {
		        // your code here
		    }

		});
		
		int h = 480; 
        mYOffset = h * 0.5f;
        mScale[0] = - (h * 0.5f * (1.0f / (SensorManager.STANDARD_GRAVITY * 2)));
        mScale[1] = - (h * 0.5f * (1.0f / (SensorManager.MAGNETIC_FIELD_EARTH_MAX)));
        
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
               runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                    	int counts = mCount-lastCount;
                    	int countsPerMinute = counts*120;
                    	transcriptArray(countsPerMinute);
                    	firstCounts++;
                    	
                    	int sum = 0;
                    	for (int i=0; i<bufferSize ; i++) {
							sum+=buffer[i];
						}
                    	
                    	int avgSum = 0;
                    	
                    	if(firstCounts<bufferSize) avgSum = (int)(sum/firstCounts);
                    	else avgSum = (int)sum/bufferSize;
                    	
            			textViewBpm.setText(avgSum+" BPM");
            			lastCount = mCount;
            			
            			if(isNetworkConnected()) {
                            new SendUdpPacketTask().execute(avgSum);
                            textViewStatus.setText(R.string.status_sending);
                        } else {
                            textViewStatus.setText(R.string.status_nonetwork);
                        }
                    }
                });
            }
        }, 0, 500);
        
        try {
            udpSocket = new DatagramSocket();
            udpSocket.setBroadcast(true);
        } catch (SocketException e) {
            e.printStackTrace();
        }
	}
	
	public void transcriptArray(int input) {
		for(int i=0; i<bufferSize-1; i++) {
			buffer[i+1] = buffer[i];
		}
		buffer[0] = input;
	}
    
    //public void onSensorChanged(int sensor, float[] values) {
	public void onSensorChanged(SensorEvent event) {
		//Log.v("moodwalker", "sensor changed");
        Sensor sensor = event.sensor; 
        
        synchronized (this) {
	        //if (sensor.getType() == Sensor.TYPE_ORIENTATION) {
	        //} else {
	            int j = (sensor.getType() == Sensor.TYPE_ACCELEROMETER) ? 1 : 0;
	            if (j == 1) {
	                float vSum = 0;
	                for (int i=0 ; i<3 ; i++) {
	                    final float v = mYOffset + event.values[i] * mScale[j];
	                    vSum += v;
	                }
	                int k = 0;
	                float v = vSum / 3;
	                //Log.v("moodwalker", "ena");
	                float direction = (v > mLastValues[k] ? 1 : (v < mLastValues[k] ? -1 : 0));
	                if (direction == - mLastDirections[k]) {
	                    // Direction changed
	                    int extType = (direction > 0 ? 0 : 1); // minumum or maximum?
	                    mLastExtremes[extType][k] = mLastValues[k];
	                    float diff = Math.abs(mLastExtremes[extType][k] - mLastExtremes[1 - extType][k]);
	
	                    if (diff > mLimit) {
	                        
	                        boolean isAlmostAsLargeAsPrevious = diff > (mLastDiff[k]*2/3);
	                        boolean isPreviousLargeEnough = mLastDiff[k] > (diff/3);
	                        boolean isNotContra = (mLastMatch != 1 - extType);
	                        
	                        if (isAlmostAsLargeAsPrevious && isPreviousLargeEnough && isNotContra) {
	                            mCount++;
	                        	
	                            textViewCount.setText("Count = "+mCount);
	                            mLastMatch = extType;
	                        }
	                        else {
	                            mLastMatch = -1;
	                        }
	                    }
	                    mLastDiff[k] = diff;
	                }
	                mLastDirections[k] = direction;
	                mLastValues[k] = v;
	            }
	        //}
        }
    }
    
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // TODO Auto-generated method stub
    }
    
    private class SendUdpPacketTask extends AsyncTask<Integer, Integer, String> {
        @Override
        protected String doInBackground(Integer... args) {
            String message = String.format("androidbpm,%d,%d",args[0],musicMode);
            System.out.println(message);
            try {
                InetAddress address = InetAddress.getByName("192.168.1.255");
                byte[] messageb = message.getBytes();

                DatagramPacket packet = new DatagramPacket(messageb, messageb.length,address, udpPort);

                udpSocket.send(packet);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return message;
        }
    }
    
    public boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        if (ni == null) {
            // There are no active networks.
            return false;
        } else {
        	return true;
        } 
    }
}