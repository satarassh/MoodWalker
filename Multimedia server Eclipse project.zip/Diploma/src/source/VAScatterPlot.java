package source;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


public class VAScatterPlot {
	// JDBC driver name and database URL
   //static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://192.168.1.172:3306/diploma";
   //static final String DB_URL = "jdbc:mysql://localhost/diploma";

   //  Database credentials
   static final String USER = "root";
   //static final String USER = "silvester";
   static final String PASS = "jaksa";
   
   public static void main(String[] args) {
	   Connection conn = null;
	   Statement stmt = null;
	   
	   XYSeriesCollection scr = new XYSeriesCollection();
	   XYSeries series = new XYSeries("VA");
	   
	   try {
	      Class.forName("com.mysql.jdbc.Driver");
	      System.out.println("Connecting to database...");
	      conn = DriverManager.getConnection(DB_URL,USER,PASS);

	      System.out.println("Creating statement...");
	      stmt = conn.createStatement();
	      String sql;
	      sql = "SELECT va_x,va_y FROM acquire_info";
	      ResultSet rs = stmt.executeQuery(sql);
	      
	      while(rs.next()){
	         int va_x = rs.getInt("va_x");
	         int va_y = rs.getInt("va_y");
	         series.add(va_x, va_y);
	         System.out.println(va_x+" "+va_y);
	      }
	      rs.close();
	      stmt.close();
	      conn.close();
	   }catch(SQLException se){
	      se.printStackTrace();
	   }catch(Exception e){
	      e.printStackTrace();
	   }finally{
	      try{
	         if(stmt!=null)
	            stmt.close();
	      }catch(SQLException se2){
	      }
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }
	   }
	   
	   scr.addSeries(series);
	   
       JFreeChart chart = ChartFactory.createScatterPlot(
           "VA results", // chart title
           "Pleasure", // x axis label
           "Activation", // y axis label
           (XYDataset)scr, // data  ***-----PROBLEM------***
           PlotOrientation.HORIZONTAL,
           false, // include legend
           true, // tooltips
           false // urls
           );
       
       XYPlot plot = (XYPlot) chart.getPlot();
       plot.setDomainZeroBaselineVisible(true);
       plot.setRangeZeroBaselineVisible(true);

       ChartFrame frame = new ChartFrame("VA results", chart);
       frame.pack();
       frame.setVisible(true);
	}
}