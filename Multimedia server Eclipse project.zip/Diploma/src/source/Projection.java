package source;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Projection extends JFrame {
    public JPanel projectionPanel;
    public int[] x = new int[8];
    public int[] y = new int[8];
    public int width = 0;
    public Color shapeColor = new Color(255,0,0);

    public Projection() {
        super("Projection");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        //setDefaultCloseOperation(EXIT_ON_CLOSE);

        projectionPanel = new GPanel();
        add(projectionPanel);
    }
    
    public void drawCustomGraphics(int[] xr, int[] yr, int w, Color c) {
    	x = xr;
    	y = yr;
    	width = w;
    	shapeColor = c;
        projectionPanel.repaint();
    }
    
    public class GPanel extends JPanel {
        public GPanel() {
        	setBackground(Color.BLACK);
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(shapeColor);

            for(int i=0; i<8; i++) {
            	if(x[i] == -1 && y[i] == -1) g.fillArc(x[i], y[i], 0, 0, 0, 360);
            	else g.fillArc(x[i], y[i], width, width, 0, 360);
            }
        }
    }

}
