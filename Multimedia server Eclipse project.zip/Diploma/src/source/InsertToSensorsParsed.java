package source;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class InsertToSensorsParsed {
	// JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost/diploma";

    //  Database credentials
    static final String USER = "silvester";
    static final String PASS = "jaksa";
    
	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		Statement bstmt = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		    System.out.println("Connecting to database...");
		    conn = DriverManager.getConnection(DB_URL,USER,PASS);
		    
		    System.out.println("Creating statement...");
		    stmt = conn.createStatement();
		    String sql;
		    sql = "SELECT id FROM acquire_info ORDER BY id DESC LIMIT 1";
		    ResultSet rs1 = stmt.executeQuery(sql);
		    
		    rs1.next();
		    int last_acquire_info_id = rs1.getInt("id");
		    
		    stmt = conn.createStatement();
		    sql = "SELECT * FROM sensors";
		    ResultSet rs = stmt.executeQuery(sql);
		      
		    boolean onBridge = false;
		    int lastIndex = 1;
		    boolean first = true;
		    boolean onlyOnce = true;
		    ArrayList<Integer> onindexes = new ArrayList<Integer>();
		    ArrayList<Integer> offindexes = new ArrayList<Integer>();
		    ArrayList<Integer> onoffids = new ArrayList<Integer>();
		    //ArrayList<Integer> firstindexes = new ArrayList<Integer>();
		    
		    bstmt = conn.createStatement();
		    while(rs.next()) {
		    	int acquire_info_id = rs.getInt("acquire_info_id");
		    	int ps1 = rs.getInt("ps1");
		    	int ps2 = rs.getInt("ps2");
		    	int ps3 = rs.getInt("ps3");
		    	int ps4 = rs.getInt("ps4");
		    	int ps5 = rs.getInt("ps5");
		    	int ps6 = rs.getInt("ps6");
		    	int ps7 = rs.getInt("ps7");
		    	int ps8 = rs.getInt("ps8");
			    float gsx = rs.getFloat("gsx");
			    float gsy = rs.getFloat("gsy");
			    float gsz = rs.getFloat("gsz");
			    
			    if(first) {
			    	first = false;
			    	lastIndex = acquire_info_id;
			    } else if(lastIndex != acquire_info_id) {
			    	onBridge = false;
			    	lastIndex = acquire_info_id;
			    	onlyOnce = true;
			    	//firstindexes.add(rs.getRow());
			    } else {
			    	lastIndex = acquire_info_id;
			    }
			    
			    if(ps1 != -1 || ps2 != -1 || ps3 != -1 || ps4 != -1 || ps5 != -1 || ps6 != -1 || ps7 != -1 || ps8 != -1) {
			    	onBridge = true;
			    	if(onlyOnce) {
			    		onoffids.add(acquire_info_id);
			    		onindexes.add(rs.getRow());
			    		onlyOnce = false;
			    	}
			    }
		    }
		    
		    onBridge = false;
		    lastIndex = last_acquire_info_id;
		    onlyOnce = true;
		    first = true;
		    rs.last();
		    
		    while(rs.previous()) {
		    	int acquire_info_id = rs.getInt("acquire_info_id");
		    	int ps1 = rs.getInt("ps1");
		    	int ps2 = rs.getInt("ps2");
		    	int ps3 = rs.getInt("ps3");
		    	int ps4 = rs.getInt("ps4");
		    	int ps5 = rs.getInt("ps5");
		    	int ps6 = rs.getInt("ps6");
		    	int ps7 = rs.getInt("ps7");
		    	int ps8 = rs.getInt("ps8");
			    float gsx = rs.getFloat("gsx");
			    float gsy = rs.getFloat("gsy");
			    float gsz = rs.getFloat("gsz");
			    
			    if(first) {
			    	first = false;
			    	lastIndex = acquire_info_id;
			    } else if(lastIndex != acquire_info_id) {
			    	onBridge = false;
			    	lastIndex = acquire_info_id;
			    	onlyOnce = true;
			    } else {
			    	lastIndex = acquire_info_id;
			    }
			    
			    if(ps1 != -1 || ps2 != -1 || ps3 != -1 || ps4 != -1 || ps5 != -1 || ps6 != -1 || ps7 != -1 || ps8 != -1) {
			    	onBridge = true;
			    	if(onlyOnce) {
			    		offindexes.add(rs.getRow());
			    		onlyOnce = false;
			    	}
			    }
		    }
		    
		    System.out.println(onindexes);
		    System.out.println(offindexes);
		    System.out.println(onoffids);
		    //System.out.println(firstindexes);
		    System.out.println("sizes: "+onindexes.size()+" "+offindexes.size()+" "+onoffids.size());
		    
		    System.out.println("Samples while being on bridge: ");
		    for (int i = 0; i < onindexes.size(); i++) {
				System.out.print((offindexes.get(offindexes.size()-1-i)-onindexes.get(i))+" ");
			}
		    System.out.println();
		    
		    //stmt = conn.createStatement();
		    //sql = "SELECT id FROM acquire_info ORDER BY id DESC LIMIT 1";
		    //ResultSet rs1 = stmt.executeQuery(sql);
		    
		    //rs1.next();
		    
		    /*
		    rs.first();
		    int onoffindex = 0;
		    
		    while(rs.next() && onoffindex < offindexes.size()) {
		    	if(rs.getRow() >= onindexes.get(onoffindex) && rs.getRow() <= offindexes.get(offindexes.size()-onoffindex-1)) {
		    		int acquire_info_id = rs.getInt("acquire_info_id");
			    	int ps1 = rs.getInt("ps1");
			    	int ps2 = rs.getInt("ps2");
			    	int ps3 = rs.getInt("ps3");
			    	int ps4 = rs.getInt("ps4");
			    	int ps5 = rs.getInt("ps5");
			    	int ps6 = rs.getInt("ps6");
			    	int ps7 = rs.getInt("ps7");
			    	int ps8 = rs.getInt("ps8");
				    float gsx = rs.getFloat("gsx");
				    float gsy = rs.getFloat("gsy");
				    float gsz = rs.getFloat("gsz");
		    		
				    sql = "INSERT INTO sensors_parsed (acquire_info_id,ps1,ps2,ps3,ps4,ps5,ps6,ps7,ps8,gsx,gsy,gsz) VALUES " + "("
	                        + acquire_info_id+","
	                        + ps1+","
	                        + ps2+","
	                        + ps3+","
	                        + ps4+","
	                        + ps5+","
	                        + ps6+","
	                        + ps7+","
	                        + ps8+","
	                        + gsx+","
	                        + gsy+","
	                        + gsz+")";
	                bstmt.addBatch(sql);
			    }
		    	
		    	if(rs.getRow() == offindexes.get(offindexes.size()-onoffindex-1)) onoffindex++;
		    }
		    
		    bstmt.executeBatch();
		    */
		    rs.close();
		    stmt.close();
		    conn.close();
	    } catch(SQLException se) {
	    	se.printStackTrace();
	    } catch(Exception e) {
	    	e.printStackTrace();
	    } finally{
	    	try {
	    		if(stmt!=null)
	            stmt.close();
	    	} catch(SQLException se2) {}
	    	try {
	    		if(conn!=null)
	            conn.close();
	    	} catch(SQLException se) {
	    		se.printStackTrace();
	    	}
	    }
	}
}
