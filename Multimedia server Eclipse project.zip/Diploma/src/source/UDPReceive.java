package source;

import java.awt.Color;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Iterator;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class UDPReceive {
	// Thread controllers
    public static Thread music;
    public static boolean runMusic = true;
    
	// Music controllers
    public static Sequencer[] midiPlayersPiano;
    public static Sequencer[] midiPlayersPenta;
    public static Sequencer[] midiPlayersBlues;
    public static String midiDir = "midi/";
    public static String mp3Dir = "mp3/";
    public static boolean isPlaying = false;

	public static ArrayList<Song> songsInfo = new ArrayList<Song>();
    
    // General global variables
    public static final int N_CHANNELS = 8;
    public static final float MAX_BPM = 500f;
    public static final int MAX_RANGE = 150;
    public static final int SOCKET_TIMEOUT = 1000; //miliseconds
    public static final int PORT = 2001;
    public static byte[] buffer = new byte[8192];
    public static final int N_SONGS = 7;
    
    public static DatagramSocket dsocket;
    
    // Frame controllers
    public static Projection projectionFrame;
    
    public static String[] pianoTones = {
        "c3.mid",
        "d3.mid",
        "e3.mid",
        "f3.mid",
        "g3.mid",
        "a3.mid",
        "h3.mid",
        "c4.mid"
    };
    
    public static String[] bluesTones = {
        "c3.mid",
        "eb3.mid",
        "f3.mid",
        "f#3.mid",
        "g3.mid",
        "bb3.mid",
        "c4.mid",
        "eb4.mid"
    };
    
    public static String[] pentaTones = {
        "penta_f#3.mid",
        "penta_g#3.mid",
        "penta_b3.mid",
        "penta_c#4.mid",
        "penta_d#4.mid",
        "penta_f#4.mid",
        "penta_g#4.mid",
        "penta_b4.mid"
    };
	
	public static void main(String args[]) {
		getSongs();
		initComponents();
		
		midiPlayersPiano = new Sequencer[N_CHANNELS];
		midiPlayersBlues = new Sequencer[N_CHANNELS];
		midiPlayersPenta = new Sequencer[N_CHANNELS];
		
		for (int i = 0; i < N_CHANNELS; i++) {
			try {
	            File midiFile1 = new File(midiDir+pianoTones[i]);
	            Sequence song1 = MidiSystem.getSequence(midiFile1);
	            midiPlayersPiano[i] = MidiSystem.getSequencer();
	            midiPlayersPiano[i].open();
	            midiPlayersPiano[i].setSequence(song1);
	            
	            File midiFile2 = new File(midiDir+bluesTones[i]);
	            Sequence song2 = MidiSystem.getSequence(midiFile2);
	            midiPlayersBlues[i] = MidiSystem.getSequencer();
	            midiPlayersBlues[i].open();
	            midiPlayersBlues[i].setSequence(song2);
	            
	            File midiFile3 = new File(midiDir+pentaTones[i]);
	            Sequence song3 = MidiSystem.getSequence(midiFile3);
	            midiPlayersPenta[i] = MidiSystem.getSequencer();
	            midiPlayersPenta[i].open();
	            midiPlayersPenta[i].setSequence(song3);
	        } catch (MidiUnavailableException e) {
	            e.printStackTrace();
	        } catch (InvalidMidiDataException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		}
		
		MusicThread mt = new MusicThread();
        music = new Thread(mt);
        music.start();
        
        try {
			dsocket = new DatagramSocket(PORT);
			dsocket.setSoTimeout(SOCKET_TIMEOUT);
			System.out.println("Socket started with timeout 1000 miliseconds");
		} catch(Exception e) {
			e.printStackTrace();
		}

        //System.out.println("Projection frame size width="+panelWidth+" height="+panelHeight);
		System.out.println("Entering loop...");
		
		int average_counter = 0;
		int every_interation = 2;
			
		while(true) {
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			try {
				dsocket.receive(packet);
			} catch (Exception e) {
				e.printStackTrace();
				dsocket.close();
				break;
			}
			
		    // Convert the contents to a string, and display them
		    String msg = new String(buffer, 0, packet.getLength());
		    // Reset the length of the packet before reusing it.
		    packet.setLength(buffer.length);
		    
		    System.out.println("Raw message:  "+msg);
		    
		    String[] msgsp = msg.split(",");

    		//System.out.println(packet.getAddress().getHostName() + ": " + msg);
    		
		    if(msgsp[0].equals("raspi")) {
		    	int musicMode = Integer.parseInt(msgsp[msgsp.length-1]);
		    	System.out.println("musicMode="+musicMode);
	    		int[] values = stringToIntArray(msgsp);
	    		//int channel = -1;
	    		int[] x = new int[N_CHANNELS];
	    		int[] y = new int[N_CHANNELS];

	    		int panelWidth = projectionFrame.projectionPanel.getWidth();
	    		int panelHeight = projectionFrame.projectionPanel.getHeight();
	    		
	    		int n_drawing = N_CHANNELS-1;

	    		float w = (float)panelWidth/(float)n_drawing*2;
		    	
		    	for(int i=0; i<values.length; i++) {
		    		if(values[i] == -1) {
		    			x[i] = -1;
			    		y[i] = -1;
		    		} else {
			    		float yp = panelHeight - (((float)panelHeight/(float)MAX_RANGE)*values[i]+(w/2));
			    		float xp = ((float)panelWidth/(float)n_drawing)*(n_drawing-i);
			    		
			    		x[i] = (int)xp;
			    		y[i] = (int)yp;
		    		}
		    		
		    		//System.out.println("REPORT: yp="+yp+" channel="+channel+" panelHeight="+panelHeight);
		    			
		    	}

		    	
		    	average_counter++;
		    	if(average_counter%every_interation == 0) {
		    		projectionFrame.drawCustomGraphics(x, y, (int)w, new Color(255,0,0));
		    		average_counter = 0;
		    	}
				
		    	if(musicMode == 0) {
				    
			    	String songId = msgsp[msgsp.length-2];
			    	float songBpm = Float.parseFloat(msgsp[msgsp.length-3]);
			    	float speed = 1.0f;
			    	if(songBpm != 0) {
			    		speed = 1.0f + (songBpm/MAX_BPM);
			    	}
			    	
			    	System.out.println("Speed="+speed);
			    	
			    	mt.receivedSpeed = speed;
			    	mt.receivedVolume = 1f;
		    	} else if(musicMode == 1) { //penta
		    		mt.receivedVolume = 0;
		    		mt.receivedSpeed = 1f;
				    
				    for (int i = 0; i < values.length; i++) {
						if(values[i] != -1 && !midiPlayersPenta[i].isRunning()) {
							midiPlayersPenta[i].start();
						} else if(values[i] == -1 && !midiPlayersPenta[i].isRunning()) {
							midiPlayersPenta[i].setMicrosecondPosition(0);
						}
					}
		    	} else if(musicMode == 2) { //blues
		    		mt.receivedVolume = 0;
		    		mt.receivedSpeed = 1f;
				    
				    for (int i = 0; i < values.length; i++) {
						if(values[i] != -1 && !midiPlayersBlues[i].isRunning()) {
							midiPlayersBlues[i].start();
						} else if(values[i] == -1 && !midiPlayersBlues[i].isRunning()) {
							midiPlayersBlues[i].setMicrosecondPosition(0);
						}
					}
		    	} else if(musicMode == 3) { //piano
		    		mt.receivedVolume = 0;
		    		mt.receivedSpeed = 1f;
				    
				    for (int i = 0; i < values.length; i++) {
						if(values[i] != -1 && !midiPlayersPiano[i].isRunning()) {
							midiPlayersPiano[i].start();
						} else if(values[i] == -1 && !midiPlayersPiano[i].isRunning()) {
							midiPlayersPiano[i].setMicrosecondPosition(0);
						}
					}
		    	}
		    	
		    }
		}
	}
	
	public static void initComponents() {
		projectionFrame = new Projection();
		projectionFrame.setVisible(true);
	}
	
	public static void getSongs() {
		JSONParser parser = new JSONParser();
		 
		try {
			Object obj = parser.parse(new FileReader("songsInfo.json"));
	 
			JSONArray jsonArray = (JSONArray) obj;
			
			for (int i = 0; i < jsonArray.size(); i++) {
				JSONObject jsonObject= (JSONObject)jsonArray.get(i);
				
				String id = (String) jsonObject.get("id");
				String genre = (String) jsonObject.get("genre");
				int rythm = ((Long) jsonObject.get("rythm")).intValue();
				int tempo = ((Long) jsonObject.get("tempo")).intValue();
				int melodious = ((Long) jsonObject.get("melodious")).intValue();
				int dynamics = ((Long) jsonObject.get("dynamics")).intValue();
				String BPM = (String) jsonObject.get("BPM");
				String mode = (String) jsonObject.get("mode");
				String harmonic_complexity = (String) jsonObject.get("harmonic_complexity");
				String consonance = (String) jsonObject.get("consonance");
				String metrum = (String) jsonObject.get("metrum");
				int red = 0;
				int green = 0;
				int blue = 0;
				
				// loop array
				JSONArray rgb = (JSONArray) jsonObject.get("RGB");
				if(rgb != null) {
					Iterator iterator = rgb.iterator();

					red = ((Long) iterator.next()).intValue();
					green = ((Long) iterator.next()).intValue();
					blue = ((Long) iterator.next()).intValue();
				}
				
				songsInfo.add(new Song(id,genre,rythm,tempo,melodious,dynamics,BPM,mode,harmonic_complexity,consonance,metrum,red,green,blue));
			}
	 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static int[] stringToIntArray(String[] stringArray) {
		int[] intArray = new int[N_CHANNELS];
		for (int i = 1; i <= N_CHANNELS; i++) {
			intArray[i-1] = Integer.parseInt(stringArray[i]);
		}
		
		return intArray;
	}
}