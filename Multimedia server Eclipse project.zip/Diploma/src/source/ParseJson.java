package source;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ParseJson {
	public static void main(String[] args) {
		ArrayList<Song> songsInfo = new ArrayList<Song>();
		JSONParser parser = new JSONParser();
		 
		try {
			Object obj = parser.parse(new FileReader("songsInfo.json"));
	 
			JSONArray jsonArray = (JSONArray) obj;
			
			for (int i = 0; i < jsonArray.size(); i++) {
				JSONObject jsonObject= (JSONObject)jsonArray.get(i);
				
				String id = (String) jsonObject.get("id");
				String genre = (String) jsonObject.get("genre");
				int rythm = ((Long) jsonObject.get("rythm")).intValue();
				int tempo = ((Long) jsonObject.get("tempo")).intValue();
				int melodious = ((Long) jsonObject.get("melodious")).intValue();
				int dynamics = ((Long) jsonObject.get("dynamics")).intValue();
				String BPM = (String) jsonObject.get("BPM");
				String mode = (String) jsonObject.get("mode");
				String harmonic_complexity = (String) jsonObject.get("harmonic_complexity");
				String consonance = (String) jsonObject.get("consonance");
				String metrum = (String) jsonObject.get("metrum");
				int red = 0;
				int green = 0;
				int blue = 0;
				
				// loop array
				JSONArray rgb = (JSONArray) jsonObject.get("RGB");
				if(rgb != null) {
					Iterator iterator = rgb.iterator();

					red = ((Long) iterator.next()).intValue();
					green = ((Long) iterator.next()).intValue();
					blue = ((Long) iterator.next()).intValue();
				}
				
				songsInfo.add(new Song(id,genre,rythm,tempo,melodious,dynamics,BPM,mode,harmonic_complexity,consonance,metrum,red,green,blue));
			}
	 
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		for (Song song : songsInfo) {
			System.out.println(song);
		}
	}
}
