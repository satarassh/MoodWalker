package source;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetChangeListener;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.AbstractXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;


public class TranslateDemo1 extends ApplicationFrame {
	private static class MyDemoPanel extends DemoPanel implements ChangeListener {
		static class TranslatingXYDataset extends AbstractXYDataset implements XYDataset, DatasetChangeListener {

			private XYDataset underlying;
			private double translate;

			public double getTranslate()
			{
				return translate;
			}

			public void setTranslate(double d)
			{
				translate = d;
				fireDatasetChanged();
			}

			public int getItemCount(int i)
			{
				return underlying.getItemCount(i);
			}

			public double getXValue(int i, int j)
			{
				return underlying.getXValue(i, j) + translate;
			}

			public Number getX(int i, int j)
			{
				return new Double(getXValue(i, j));
			}

			public Number getY(int i, int j)
			{
				return new Double(getYValue(i, j));
			}

			public double getYValue(int i, int j)
			{
				return underlying.getYValue(i, j);
			}

			public int getSeriesCount()
			{
				return underlying.getSeriesCount();
			}

			public Comparable getSeriesKey(int i)
			{
				return underlying.getSeriesKey(i);
			}

			public void datasetChanged(DatasetChangeEvent datasetchangeevent)
			{
				fireDatasetChanged();
			}

			public TranslatingXYDataset(XYDataset xydataset)
			{
				underlying = xydataset;
				underlying.addChangeListener(this);
				translate = 0.0D;
			}
		}


		private TimeSeries series_x, series_y, series_z;
		private ChartPanel chartPanel;
		private JFreeChart chart;
		private TranslatingXYDataset dataset_x, dataset_y, dataset_z;
		
		// JDBC driver name and database URL
	    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	    //static final String DB_URL = "jdbc:mysql://192.168.1.172:3306/diploma";
	    static final String DB_URL = "jdbc:mysql://localhost/diploma";

	    //  Database credentials
	    //static final String USER = "root";
	    static final String USER = "silvester";
	    static final String PASS = "jaksa";
	    
	    static String stmt_info;

		private JFreeChart createChart(XYDataset ds, String title) {
			JFreeChart jfreechart = ChartFactory.createTimeSeriesChart(title+"\n"+stmt_info, "Time", "Value", ds, false, false, false);
			XYPlot xyplot = (XYPlot)jfreechart.getPlot();
			xyplot.setOrientation(PlotOrientation.VERTICAL);
			xyplot.setDomainCrosshairVisible(true);
			xyplot.setDomainCrosshairLockedOnData(false);
			xyplot.setRangeCrosshairVisible(false);
			DateAxis dateaxis = (DateAxis)xyplot.getDomainAxis();
			org.jfree.data.Range range = DatasetUtilities.findDomainBounds(ds);
			dateaxis.setRange(range);
			dateaxis.setVisible(false);
			return jfreechart;
		}

		private void createDatasets(RegularTimePeriod regulartimeperiod) {
			series_x = new TimeSeries("Acc X");
			series_y = new TimeSeries("Acc Y");
			series_z = new TimeSeries("Acc Z");
			RegularTimePeriod regulartimeperiod1 = regulartimeperiod;
			Connection conn = null;
			Statement stmt = null;
			
			int idb = 84;
			
			try {
		      Class.forName("com.mysql.jdbc.Driver");
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);
		      
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String sql;
		      //sql = "SELECT * FROM sensors WHERE acquire_info_id=60 AND (ps1<>-1 OR ps2<>-1 OR ps3<>-1 OR ps4<>-1 OR ps5<>-1 OR ps6<>-1 OR ps7<>-1 OR ps8<>-1)";
		      sql = "SELECT va_x,va_y,email,samples,seconds,date FROM acquire_info WHERE id="+idb;
		      ResultSet rs1 = stmt.executeQuery(sql);
		      
		      while(rs1.next()) {
		         String va_x = rs1.getString("va_x");
		         String va_y = rs1.getString("va_y");
		         String email = rs1.getString("email");
		         int samples = rs1.getInt("samples");
		         String seconds = rs1.getString("seconds");
		         String date = rs1.getString("date");
		         
		         stmt_info = date+"  email="+email+"  samples="+samples+"  seconds="+seconds+"  va_x="+va_x+" va_y="+va_y;
		      }
		
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      //sql = "SELECT * FROM sensors WHERE acquire_info_id=60 AND (ps1<>-1 OR ps2<>-1 OR ps3<>-1 OR ps4<>-1 OR ps5<>-1 OR ps6<>-1 OR ps7<>-1 OR ps8<>-1)";
		      sql = "SELECT * FROM sensors WHERE acquire_info_id="+idb;
		      ResultSet rs2 = stmt.executeQuery(sql);
		      
		      boolean onBridge = false;
		      
		      while(rs2.next()) {
		         float gsx = -rs2.getFloat("gsx");
		         float gsy = -rs2.getFloat("gsy");
		         float gsz = -rs2.getFloat("gsz");
		         series_x.add(regulartimeperiod1, gsx);
		         series_y.add(regulartimeperiod1, gsy);
		         series_z.add(regulartimeperiod1, gsz);
				 regulartimeperiod1 = regulartimeperiod1.next();
				 System.out.println(gsx+" "+gsy+" "+gsz);
		      }
		      rs1.close();
		      rs2.close();
		      stmt.close();
		      conn.close();
		   }catch(SQLException se){
		      se.printStackTrace();
		   }catch(Exception e){
		      e.printStackTrace();
		   }finally{
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		   }
			
			System.out.println("Fetching successful!");

			TimeSeriesCollection tscx = new TimeSeriesCollection();
			tscx.addSeries(series_x);
			dataset_x = new TranslatingXYDataset(tscx);
			
			TimeSeriesCollection tscy = new TimeSeriesCollection();
			tscy.addSeries(series_y);
			dataset_y = new TranslatingXYDataset(tscy);
			
			TimeSeriesCollection tscz = new TimeSeriesCollection();
			tscz.addSeries(series_z);
			dataset_z = new TranslatingXYDataset(tscz);
		}
		
		public void stateChanged(ChangeEvent changeevent) {
			System.out.println();
		}

		public MyDemoPanel(int mode) {
			super(new BorderLayout());
			createDatasets(new Second());
			
			if(mode==1) {
				chart = createChart(dataset_x, "Accelerometer X");
				addChart(chart);
				chartPanel = new ChartPanel(chart);
				chartPanel.setPreferredSize(new Dimension(600, 270));
				chartPanel.setDomainZoomable(true);
				chartPanel.setRangeZoomable(true);
				javax.swing.border.CompoundBorder compoundborder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createEtchedBorder());
				chartPanel.setBorder(compoundborder);
				add(chartPanel);
			} else if(mode==2) {
				chart = createChart(dataset_y, "Accelerometer Y");
				addChart(chart);
				chartPanel = new ChartPanel(chart);
				chartPanel.setPreferredSize(new Dimension(600, 270));
				chartPanel.setDomainZoomable(true);
				chartPanel.setRangeZoomable(true);
				javax.swing.border.CompoundBorder compoundborder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createEtchedBorder());
				chartPanel.setBorder(compoundborder);
				add(chartPanel);
			} else if(mode==3) {
				chart = createChart(dataset_z, "Accelerometer Z");
				addChart(chart);
				chartPanel = new ChartPanel(chart);
				chartPanel.setPreferredSize(new Dimension(600, 270));
				chartPanel.setDomainZoomable(true);
				chartPanel.setRangeZoomable(true);
				javax.swing.border.CompoundBorder compoundborder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createEtchedBorder());
				chartPanel.setBorder(compoundborder);
				add(chartPanel);
			}
			
			JPanel jpanel = new JPanel(new BorderLayout());
			jpanel.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
			add(jpanel, "South");
		}
	}


	public TranslateDemo1(String s, int mode)
	{
		super(s);
		setContentPane(new MyDemoPanel(mode));
	}

	public static void main(String args[])
	{
		TranslateDemo1 td1x = new TranslateDemo1("Accelerometer X", 1);
		td1x.pack();
		RefineryUtilities.centerFrameOnScreen(td1x);
		td1x.setVisible(true);
		
		TranslateDemo1 td1y = new TranslateDemo1("Accelerometer Y", 2);
		td1y.pack();
		RefineryUtilities.centerFrameOnScreen(td1y);
		td1y.setVisible(true);
		
		TranslateDemo1 td1z = new TranslateDemo1("Accelerometer Z", 3);
		td1z.pack();
		RefineryUtilities.centerFrameOnScreen(td1z);
		td1z.setVisible(true);
	}
}