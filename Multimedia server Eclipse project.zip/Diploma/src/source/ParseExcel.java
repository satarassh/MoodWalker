package source;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ParseExcel {

	public static void main(String[] args) {
		Workbook workbook_muzikologi = null;
		Workbook workbook_vprasalnik = null;
		Sheet sheet_muzikologi = null;
		Sheet sheet_vprasalnik = null;
		try {
			workbook_muzikologi = Workbook.getWorkbook(new File("template_pesmi_muzikologi.xls"));
			sheet_muzikologi = workbook_muzikologi.getSheet(0);
			
			workbook_vprasalnik = Workbook.getWorkbook(new File("FixedVprasalnikIzluscen.xls"));
			sheet_vprasalnik = workbook_vprasalnik.getSheet(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		ArrayList<Song> songsInfo = new ArrayList<Song>();
		
		for(int it=2; it<196; it++) {
			Cell a = sheet_muzikologi.getCell(0,it); 
			Cell b = sheet_muzikologi.getCell(1,it); 
			Cell c = sheet_muzikologi.getCell(2,it); 
			Cell d = sheet_muzikologi.getCell(3,it); 
			Cell e = sheet_muzikologi.getCell(4,it); 
			Cell f = sheet_muzikologi.getCell(5,it);
			Cell g = sheet_muzikologi.getCell(6,it); 
			Cell h = sheet_muzikologi.getCell(7,it); 
			Cell i = sheet_muzikologi.getCell(8,it);
			Cell j = sheet_muzikologi.getCell(9,it); 
			Cell k = sheet_muzikologi.getCell(10,it); 
			
			String id = a.getContents();
			String genre = b.getContents();
			int rythm = Integer.parseInt(c.getContents());
			int tempo = Integer.parseInt(d.getContents());
			int melodious = Integer.parseInt(e.getContents());
			int dynamics = Integer.parseInt(f.getContents());
			String BPM = g.getContents();
			String mode = h.getContents();
			String harmonic_complexity = i.getContents();
			String consonance = j.getContents();
			String metrum = k.getContents();
			
			if(!BPM.equals("undefined")) BPM = BPM.replaceAll("\\D+","");
			
			songsInfo.add(new Song(id, genre, rythm, tempo, melodious, dynamics, BPM, mode, harmonic_complexity, consonance, metrum));
		}

		int lastSong = Integer.parseInt(sheet_vprasalnik.getCell(11,1).getContents());
		float tempH = Float.parseFloat(sheet_vprasalnik.getCell(14,1).getContents());
		float tempS = Float.parseFloat(sheet_vprasalnik.getCell(15,1).getContents());
		float tempV = Float.parseFloat(sheet_vprasalnik.getCell(16,1).getContents());
		int tempCount = 1;
		
		for(int it=2; it<sheet_vprasalnik.getRows(); it++) {
			Cell l = sheet_vprasalnik.getCell(11,it);
			Cell o = sheet_vprasalnik.getCell(14,it);
			Cell p = sheet_vprasalnik.getCell(15,it);
			Cell q = sheet_vprasalnik.getCell(16,it);
			
			int song = Integer.parseInt(l.getContents());
			float h = Float.parseFloat(o.getContents());
			float s = Float.parseFloat(p.getContents());
			float v = Float.parseFloat(q.getContents());
			
			if(song != lastSong) {
				tempH = tempH/tempCount;
				tempS = tempS/tempCount;
				tempV = tempV/tempCount;
				System.out.println(lastSong+".mp3 avgH="+tempH+" avgS="+tempS+" avgV="+tempV);
				
				Song sng = getSongById(lastSong+".mp3", songsInfo);
				if(sng != null) sng.setColor(tempH, tempS, tempV);
				
				tempCount = 1;
				lastSong = song;
				tempH = h;
				tempS = s;
				tempV = v;
			} else {
				tempCount++;
				lastSong = song;
				tempH += h;
				tempS += s;
				tempV += v;
			}
		}
		
		tempH = tempH/tempCount;
		tempS = tempS/tempCount;
		tempV = tempV/tempCount;
		System.out.println(lastSong+".mp3 avgH="+tempH+" avgS="+tempS+" avgV="+tempV);
		
		Song sng = getSongById(lastSong+".mp3", songsInfo);
		if(sng != null) sng.setColor(tempH, tempS, tempV);

		for(int i=0; i<songsInfo.size(); i++) {
			if(i != 0) {
				if(songsInfo.get(i).id.compareTo(songsInfo.get(i-1).id) < 0) System.out.println("!!!!   Ni po vrsti   !!!!");
			} 
			System.out.println(songsInfo.get(i).id+" "+songsInfo.get(i).BPM+" "+songsInfo.get(i).RGB);
		}
		
		/* Ne poganjaj ker ni dobro!
		ArrayList<JSONObject> allJsonObjects = new ArrayList<JSONObject>();
		
		for (Song s : songsInfo) {
			JSONObject obj = new JSONObject();
			obj.put("id", s.id);
			obj.put("genre", s.genre);
			obj.put("rythm", new Integer(s.rythm));
			obj.put("tempo", new Integer(s.tempo));
			obj.put("melodious", new Integer(s.melodious));
			obj.put("dynamics", new Integer(s.dynamics));
			obj.put("BPM", s.BPM);
			obj.put("mode", s.mode);
			obj.put("harmonic_complexity", s.harmonic_complexity);
			obj.put("consonance", s.consonance);
			obj.put("metrum", s.metrum);
			
			if(s.RGB != null) {
				JSONArray list = new JSONArray();
				list.add(s.RGB.getRed());
				list.add(s.RGB.getGreen());
				list.add(s.RGB.getBlue());
				
				obj.put("RGB", list);
			}
			
			allJsonObjects.add(obj);
		}
		
		try {
			FileWriter file = new FileWriter("songsInfo.json");
			
			for (JSONObject jo : allJsonObjects) {
				file.write(jo.toJSONString());
				file.write("\n");
			}
			
			file.flush();
			file.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
	}
	
	public static Song getSongById(String id, ArrayList<Song> songs) {
		for (Song s : songs) {
			if(s.id.equals(id)) return s;
		}
		
		return null;
	}
	
	public static String hsvToRgb(float hue, float saturation, float value) {
	    int h = (int)(hue * 6);
	    float f = hue * 6 - h;
	    float p = value * (1 - saturation);
	    float q = value * (1 - f * saturation);
	    float t = value * (1 - (1 - f) * saturation);

	    switch (h) {
	      case 0: return rgbToString(value, t, p);
	      case 1: return rgbToString(q, value, p);
	      case 2: return rgbToString(p, value, t);
	      case 3: return rgbToString(p, q, value);
	      case 4: return rgbToString(t, p, value);
	      case 5: return rgbToString(value, p, q);
	      default: throw new RuntimeException("Something went wrong when converting from HSV to RGB. Input was " + hue + ", " + saturation + ", " + value);
	    }
	}

	public static String rgbToString(float r, float g, float b) {
	    String rs = Integer.toHexString((int)(r * 256));
	    String gs = Integer.toHexString((int)(g * 256));
	    String bs = Integer.toHexString((int)(b * 256));
	    return rs + gs + bs;
	}
}
