package source;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import javax.swing.Timer;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import pwm.PWMPin;

/**
 *
 * @author silvesterjaksa
 */
public class NoVisu {
    // Thread controllers
    public static Thread music;
    public static boolean runMusic = true;
    public static Thread sensors;
    public static boolean runSensors = true;
    public static Thread data;
    //public static boolean runData = false;
    public static Thread dim;
    public static boolean runGyro = true;
    public static Thread gyro;
    public static boolean runDim = false;
    public static final int threadCycle = 50;
    
    // Data controllers
    public static final int N_CHANNELS = 8;
    public static double[] ranges = new double[8];
    public static final double MAX_RANGE = 150.0;
    public static String dataDir = "data/";
    public static Timer okIndicatorTimer;
    public static ArrayList<ClientData> clientsData;
    public static ArrayList<Song> songsInfo;
    public static int BPM = 0;
    public static int musicMode = 0;
    public static String playingSong = "101.mp3";
    public static final int MAX_SONG_BUFFER = 5;
    
    // RGB controllers
    public static final int RED = 0;
    public static final int GREEN = 1;
    public static final int BLUE = 2;
    public static PWMPin[] rgbs;
    
    // GPIO controllers
    public static GpioController gpio;
    public static GpioPinDigitalOutput CS;
    public static GpioPinDigitalOutput OK_indicator;
    public static GpioPinDigitalOutput START_indicator;
    public static GpioPinDigitalOutput STOP_indicator;
    
    // UDP Controllers
    public static int udpPort = 2000;
    public static DatagramSocket udpSocket;
    public static int udpSendingPort = 2001;
    public static DatagramSocket udpSendingSocket;
    
    
    public static void main(String[] args) throws Exception {
        songsInfo = new ArrayList<Song>();
        readJson();
        
        gpio = GpioFactory.getInstance();
        CS = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_10, PinState.LOW);
        OK_indicator = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_26, PinState.LOW);
        START_indicator = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_24, PinState.LOW);
        STOP_indicator = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_23, PinState.LOW);
        
        okIndicatorTimer = new Timer(250, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if(OK_indicator.isLow()) OK_indicator.setState(PinState.HIGH);
                else OK_indicator.setState(PinState.LOW);
            }
        });
        
        okIndicatorTimer.start();
        
        PWMPin pinRed = new PWMPin(RaspiPin.GPIO_28, "redPin", PinState.LOW);       // Pin 37 (Rpi), Pin 3 (Triac)
        PWMPin pinGreen = new PWMPin(RaspiPin.GPIO_22, "greenPin", PinState.LOW);   // Pin 40 (Rpi), Pin 1 (Triac)
        PWMPin pinBlue = new PWMPin(RaspiPin.GPIO_29, "bluePin", PinState.LOW);     // Pin 38 (Rpi), Pin 2 (Triac)
        
        rgbs = new PWMPin[3];
        rgbs[0] = pinRed;
        rgbs[1] = pinGreen;
        rgbs[2] = pinBlue;
        
        for (int i = 0; i < 3; i++) {
            rgbs[i].low();
            rgbs[i].emitPWM(0);
        }
        
        try {
            udpSocket = new DatagramSocket(udpPort);
            udpSendingSocket = new DatagramSocket(udpSendingPort);
            udpSendingSocket.setBroadcast(true);
        } catch (SocketException e) {
            e.printStackTrace();
            okIndicatorTimer.stop();
            OK_indicator.setState(PinState.LOW);
        }
        
        ProximitySensorThread st = new ProximitySensorThread();
        sensors = new Thread(st);
        sensors.start();
        
        //GyroscopeSensorThread gt = new GyroscopeSensorThread();
        //gyro = new Thread(gt);
        //gyro.start();
        
        byte[] buffer = new byte[2048];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        
        float[] gyroData = new float[3];
        clientsData = new ArrayList<ClientData>();
        
        while(true) {
            //Thread.sleep(threadCycle);
            
            try {
                // Wait to receive a datagram
                udpSocket.receive(packet);
            } catch (Exception e) {
                e.printStackTrace();
                okIndicatorTimer.stop();
                OK_indicator.setState(PinState.LOW);
            }

            String msg = new String(buffer, 0, packet.getLength());
            String[] msgsp = msg.split(",");
            
            packet.setLength(buffer.length);
            
            //String message = String.format("raspi,%d,%d,%d,%d,%d,%d,%d,%d",(int)ranges[0],(int)ranges[1],(int)ranges[2],(int)ranges[3],(int)ranges[4],(int)ranges[5],(int)ranges[6],(int)ranges[7]);
            //System.out.println(message);
            
            ClientData c = getClientObject(msgsp[1]);
            
            if(msgsp[0].equals("androidstart")) {
                clientsData.add(new ClientData(msgsp[1]));
                
                gyroData = stringToFloatArray(msgsp);
                START_indicator.setState(PinState.HIGH);
            } else if(msgsp[0].equals("androidstop") && c != null) {
                c.runData = false;
                c.secondsTimer.stop();
                STOP_indicator.setState(PinState.HIGH);
            } else if(msgsp[0].equals("androidva") && c != null) {
                c.temporaryDataVaX = msgsp[2];
                c.temporaryDataVaY = msgsp[3];
                
                double centis = ((double)c.seconds/10);
                
                System.out.println(String.format("%.1f",centis));
                System.out.println(c.email);
                System.out.println("X="+c.temporaryDataVaX+" Y="+c.temporaryDataVaY);
                
                for(ProximityData d : c.temporaryDataProximity) {
                    System.out.print(d);
                }
                
                for(GyroscopeData d : c.temporaryDataGyroscope) {
                    System.out.print(d);
                }
                
                DatabaseThread dbt = new DatabaseThread(c);
                Thread dt = new Thread(dbt);
                dt.start();
                
                clientsData.remove(c);
                
                START_indicator.setState(PinState.LOW);
                STOP_indicator.setState(PinState.LOW);
            } else if(msgsp[0].equals("androidbpm")) {
                BPM = Integer.parseInt(msgsp[1]);
                musicMode = Integer.parseInt(msgsp[2]);
                ArrayList<Song> als = findSongByBpm(BPM);
                int si = (int) (Math.random() * (als.size()-1));
                Song s = als.get(si);
                if(musicMode == 0) adjustLed(s.RGB.getRed(), s.RGB.getGreen(), s.RGB.getBlue());
                playingSong = s.id;
                
                System.out.println("Found song "+s.id+" with BPM="+s.BPM+" on android measured BPM="+BPM+" mode="+musicMode);
            } else {
                gyroData = stringToFloatArray(msgsp);
            }
            
            if(c != null && c.runData) {
                c.temporaryDataProximity.add(new ProximityData(
                    (int)ranges[0],
                    (int)ranges[1],
                    (int)ranges[2],
                    (int)ranges[3],
                    (int)ranges[4],
                    (int)ranges[5],
                    (int)ranges[6],
                    (int)ranges[7]
                ));
                
                c.temporaryDataGyroscope.add(new GyroscopeData(
                    gyroData[0],
                    gyroData[1],
                    gyroData[2]
                ));
            }
        }
    }
    
    public static void adjustLed(int red, int green, int blue) {
        float redPercent = (red/255f)*100;
        float greenPercent = (green/255f)*100;
        float bluePercent = (blue/255f)*100;
        
        System.out.println("Adjusted RGB("+red+","+green+","+blue+") percentages: "+redPercent+" "+greenPercent+" "+bluePercent);
        
        rgbs[RED].adjustPWMVolume((int)redPercent);
        rgbs[GREEN].adjustPWMVolume((int)greenPercent);
        rgbs[BLUE].adjustPWMVolume((int)bluePercent);
    }
    
    public static ArrayList<Song> findSongByBpm(int bpm) {
        int min = bpm-Integer.parseInt(songsInfo.get(0).BPM);
        if(min<0) min*=(-1);
        
        ArrayList<Song> returnSongs = new ArrayList<Song>();
        returnSongs.add(songsInfo.get(0));
        
        for (Song song : songsInfo) {
            if(!song.BPM.equals("undefined")) {
                int sbpm = Integer.parseInt(song.BPM);
                int val = bpm-sbpm;
                if(val<0) val*=(-1);
                
                if(val<min) {
                    min=val;
                    returnSongs.add(song);
                    if(returnSongs.size() >= MAX_SONG_BUFFER) {
                        returnSongs.remove(0);
                    }
                }
            }
        }
        
        return returnSongs;
    }
    
    public static ClientData getClientObject(String email) {
        for (ClientData c : clientsData) {
            if(c.email.equals(email)) return c;
        }
        
        return null;
    }
    
    public static float[] stringToFloatArray(String[] stringArray) {
        float[] floatArray = new float[stringArray.length-1];
        for (int i = 2; i < stringArray.length; i++) {
                if(stringArray[i].equals("-0.0000")) stringArray[i] = "0.0000";
                floatArray[i-2] = Float.parseFloat(stringArray[i]);
        }

        return floatArray;
    }
    
    public static String zero(int num) {
        String number = (num < 10) ? ("0"+num) : (""+num);
        return number;                 
    }
    
    public static String getCurrentTime(boolean seconds) {
        Calendar now = Calendar.getInstance();
        int hrs = now.get(Calendar.HOUR_OF_DAY);
        int min = now.get(Calendar.MINUTE);
        int sec = now.get(Calendar.SECOND);
        
        if(seconds) return zero(hrs)+":"+zero(min)+":"+zero(sec);
        return zero(hrs)+":"+zero(min);
    }
    
    public static String getCurrentDate() {
        Calendar now = Calendar.getInstance();
        int day = now.get(Calendar.DATE);
        int month = now.get(Calendar.MONTH)+1;
        int year = now.get(Calendar.YEAR);
        
        return day+"."+month+"."+year;
    }
    
    public static void readJson() {
        JSONParser parser = new JSONParser();

        try {
            Object obj = parser.parse(new FileReader("songsInfo.json"));

            JSONArray jsonArray = (JSONArray) obj;

            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject= (JSONObject)jsonArray.get(i);

                String id = (String) jsonObject.get("id");
                String genre = (String) jsonObject.get("genre");
                int rythm = ((Long) jsonObject.get("rythm")).intValue();
                int tempo = ((Long) jsonObject.get("tempo")).intValue();
                int melodious = ((Long) jsonObject.get("melodious")).intValue();
                int dynamics = ((Long) jsonObject.get("dynamics")).intValue();
                String BPM = (String) jsonObject.get("BPM");
                String mode = (String) jsonObject.get("mode");
                String harmonic_complexity = (String) jsonObject.get("harmonic_complexity");
                String consonance = (String) jsonObject.get("consonance");
                String metrum = (String) jsonObject.get("metrum");
                int red = 0;
                int green = 0;
                int blue = 0;

                JSONArray rgb = (JSONArray) jsonObject.get("RGB");
                if(rgb != null) {
                    Iterator iterator = rgb.iterator();

                    red = ((Long) iterator.next()).intValue();
                    green = ((Long) iterator.next()).intValue();
                    blue = ((Long) iterator.next()).intValue();
                }

                songsInfo.add(new Song(id,genre,rythm,tempo,melodious,dynamics,BPM,mode,harmonic_complexity,consonance,metrum,red,green,blue));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        /*
        for (Song song : songsInfo) {
            System.out.println(song);
        }
        */
    }
}
