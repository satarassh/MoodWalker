package source;

/**
 *
 * @author silvesterjaksa
 */
public class GyroscopeData {
    public float[] data;
    
    public GyroscopeData(float x, float y, float z) {
        this.data = new float[3];
        data[0] = x;
        data[1] = y;
        data[2] = z;
    }
    
    @Override
    public String toString() {
        return String.format("%.4f %.4f %.4f\n",data[0],data[1],data[2]);
    }
}
