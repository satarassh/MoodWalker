package source;

import static source.NoVisu.N_CHANNELS;

/**
 *
 * @author silvesterjaksa
 */
public class ProximityData {
    public int[] data;
    
    public ProximityData(int d1, int d2, int d3, int d4, int d5, int d6, int d7, int d8) {
        this.data = new int[N_CHANNELS];
        data[0] = d1;
        data[1] = d2;
        data[2] = d3;
        data[3] = d4;
        data[4] = d5;
        data[5] = d6;
        data[6] = d7;
        data[7] = d8;
    }
    
    @Override
    public String toString() {
        return String.format("%3d%4d%4d%4d%4d%4d%4d%4d\n",data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7]);
    }
}
