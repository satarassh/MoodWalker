package source;

import com.pi4j.io.gpio.PinState;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import static source.NoVisu.OK_indicator;
import static source.NoVisu.getCurrentDate;
import static source.NoVisu.getCurrentTime;
import static source.NoVisu.okIndicatorTimer;

/**
 *
 * @author silvesterjaksa
 */
public class DatabaseThread implements Runnable {
    ClientData cd;
    
    // DB Controllers
    // JDBC driver name and database URL
    //private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    private static final String DB_URL = "jdbc:mysql://localhost/diploma";

    // Database credentials
    private static final String USER = "root";
    private static final String PASS = "jaksa";

    public DatabaseThread(ClientData c) {
        this.cd = c;
    }
    
    @Override
    public void run() {
        insertInfoToDatabase(cd);
        System.out.println("Exiting...");
    }
    
    public void insertInfoToDatabase(ClientData c) {
        Connection conn = null;
        Statement stmt = null;
        
        int samples = c.temporaryDataGyroscope.size();
        double centis = ((double)c.seconds/10);
        String cts = String.format("%.1f",centis);
        String date = getCurrentDate()+" - "+getCurrentTime(true);

        try {
            // Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Open a connection
            System.out.print("\nConnecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println(" SUCCESS!");

            // Excute insert query into acquire_info
            System.out.print("Inserting acquire_info records into table...");
            stmt = conn.createStatement();

            String sql = "INSERT INTO acquire_info (email,samples,seconds,va_x,va_y,date) VALUES ('"+c.email+"',"+samples+",'"+cts+"',"+c.temporaryDataVaX+","+c.temporaryDataVaY+",'"+date+"')";
            stmt.executeUpdate(sql);
            System.out.println(" SUCCESS!");
            
            // Fetch last id
            System.out.print("Fetching last id from acquire_info...");
            sql = "SELECT id FROM acquire_info ORDER BY id DESC LIMIT 1";
            ResultSet resultSet = stmt.executeQuery(sql);
            System.out.println(" SUCCESS!");
            resultSet.next();
            int lastId = resultSet.getInt("id");
            
            // Excute insert batch into sensors
            System.out.print("Inserting sensors records into table...");
            stmt = conn.createStatement();
            
            for (int i = 0; i < samples; i++) {
                sql = "INSERT INTO sensors (acquire_info_id,ps1,ps2,ps3,ps4,ps5,ps6,ps7,ps8,gsx,gsy,gsz) VALUES " + "("
                        + lastId+","
                        + c.temporaryDataProximity.get(i).data[0]+","
                        + c.temporaryDataProximity.get(i).data[1]+","
                        + c.temporaryDataProximity.get(i).data[2]+","
                        + c.temporaryDataProximity.get(i).data[3]+","
                        + c.temporaryDataProximity.get(i).data[4]+","
                        + c.temporaryDataProximity.get(i).data[5]+","
                        + c.temporaryDataProximity.get(i).data[6]+","
                        + c.temporaryDataProximity.get(i).data[7]+","
                        + c.temporaryDataGyroscope.get(i).data[0]+","
                        + c.temporaryDataGyroscope.get(i).data[1]+","
                        + c.temporaryDataGyroscope.get(i).data[2]+")";
                stmt.addBatch(sql);
            }
            stmt.executeBatch();
            System.out.println(" SUCCESS!");
        } catch(SQLException se) {
            se.printStackTrace();
            okIndicatorTimer.stop();
            OK_indicator.setState(PinState.LOW);
        } catch(Exception e) {
            e.printStackTrace();
            okIndicatorTimer.stop();
            OK_indicator.setState(PinState.LOW);
        } finally {
            try {
                if(stmt != null)
                    conn.close();
            } catch(SQLException se) {
            }
            try {
                if(conn != null)
                    conn.close();
            } catch(SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("Closing connection!");
    }
}
