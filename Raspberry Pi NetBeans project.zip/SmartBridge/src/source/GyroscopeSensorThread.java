package source;

import java.net.DatagramPacket;
import static source.NoVisu.runGyro;
import static source.NoVisu.udpSocket;

/**
 *
 * @author silvesterjaksa
 */
public class GyroscopeSensorThread implements Runnable {
    @Override
    public void run() {
        byte[] buffer = new byte[2048];
	DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        
        while(runGyro) {
            try {
                // Wait to receive a datagram
                udpSocket.receive(packet);
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Convert the contents to a string
            String msg = new String(buffer, 0, packet.getLength());
            System.out.println(packet.getAddress().getHostName() + ": " + msg);
            // Reset the length of the packet before reusing it.
            packet.setLength(buffer.length);
        }
        
        udpSocket.close();
    }
}
