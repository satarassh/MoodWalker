package source;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.Timer;

/**
 *
 * @author silvesterjaksa
 */
public class ClientData {
    public String email;
    public boolean runData;
    public ArrayList<ProximityData> temporaryDataProximity;
    public ArrayList<GyroscopeData> temporaryDataGyroscope;
    public String temporaryDataVaX;
    public String temporaryDataVaY;
    public Timer secondsTimer;
    public int seconds = 0;
    
    public ClientData(String e) {
        this.email = e;
        temporaryDataProximity = new ArrayList<ProximityData>();
        temporaryDataGyroscope = new ArrayList<GyroscopeData>();
        secondsTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                seconds++;
            }
        });

        secondsTimer.start();
        runData = true;
    }
}
