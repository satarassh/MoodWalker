package source;

import com.pi4j.io.gpio.PinState;
import com.pi4j.io.spi.SpiChannel;
import com.pi4j.io.spi.SpiDevice;
import com.pi4j.io.spi.SpiFactory;
import com.pi4j.io.spi.SpiMode;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import static source.NoVisu.BLUE;
import static source.NoVisu.BPM;
import static source.NoVisu.CS;
import static source.NoVisu.GREEN;
import static source.NoVisu.N_CHANNELS;
import static source.NoVisu.RED;
import static source.NoVisu.musicMode;
import static source.NoVisu.playingSong;
import static source.NoVisu.ranges;
import static source.NoVisu.rgbs;
import static source.NoVisu.runSensors;
import static source.NoVisu.udpSendingPort;
import static source.NoVisu.udpSendingSocket;

/**
 *
 * @author silvesterjaksa
 */
public class ProximitySensorThread implements Runnable {
    // SPI device
    public SpiDevice spi = null;

    // SPI operations
    public byte[] SELECT_CHANNEL = {
        (byte) 0x87,
        (byte) 0xC7,
        (byte) 0x97,
        (byte) 0xD7,
        (byte) 0xA7,
        (byte) 0xE7,
        (byte) 0xB7,
        (byte) 0xF7
    };
    
    // Global variables
    public final double A = 0.4194;
    public final double B = 3.657;
    public final double C = -0.02884;
    public final int AV_MAX = 4; // tells how many loop cycles will pass before results will be set on average
    public final double VOLT_MAX = 2.75;
    public final double MAX_RANGE = 150.0;
    public final double MIN_RANGE = 15.0;
    
    public int averageIndex = 0;
    public double[][] tempRanges;
    
    public ProximitySensorThread() {
        // create SPI object instance for SPI for communication
        try {
            spi = SpiFactory.getInstance(SpiChannel.CS0,
                                         SpiDevice.DEFAULT_SPI_SPEED, // default spi speed 1 MHz
                                         SpiMode.MODE_3); // default spi mode 0
        } catch(IOException e) {}
        
        tempRanges = new double[N_CHANNELS][AV_MAX];
    }
    
    public void read(int channel) throws IOException {
        byte packet1 = SELECT_CHANNEL[channel];
        byte packet2 = 0x00;
        
        byte[] result1;
        byte[] result2;
        byte[] result3;
        byte[] result4;
        byte[] finalResult = new byte[2];
        
        CS.setState(PinState.LOW);
        result1 = spi.write(packet1);
        result2 = spi.write(packet2);
        result3 = spi.write(packet2);
        result4 = spi.write(packet2);
        CS.setState(PinState.HIGH);
        
        //int temp = (int)result1[0];
        
        int result = (int)result2[0] << 8;
        int temp = (int)result3[0] & 0x000000FF;
        result |= temp;
        result = result << 1;
        result = result + ((int)result4[0]>>7);
        result = result >> 4;
        
        finalResult[0] = (byte) (result >> 8);
        finalResult[1] = (byte) (result);
        
        double voltage = VOLT_MAX * ((double)result/4095);
        
        if(voltage-A > 0) {
            double range = (Math.log(voltage-A)-Math.log(B))/C;
            
            tempRanges[channel][averageIndex] = range;
        } else {
            tempRanges[channel][averageIndex] = -1;
        }
    }
    
    public String bytesToBinary(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        int v;
        for ( int j = 0; j < bytes.length; j++ ) {
            v = bytes[j];
            sb.append(Integer.toBinaryString(v));
        }
        return sb.toString();
    }    

    public String bytesToHex(byte[] bytes) {
        final char[] hexArray = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        char[] hexChars = new char[bytes.length * 2];
        int v;
        for ( int j = 0; j < bytes.length; j++ ) {
            v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
    
    public void adjustLedByPosition(int channel, int range) {
        switch(channel) {
            case 0:     rgbs[RED].adjustPWMVolume(range);
                        rgbs[GREEN].adjustPWMVolume(0);
                        rgbs[BLUE].adjustPWMVolume(0);
                        break;  
                
            case 1:     rgbs[RED].adjustPWMVolume(0);
                        rgbs[GREEN].adjustPWMVolume(range);
                        rgbs[BLUE].adjustPWMVolume(0);
                        break;
                
            case 2:     rgbs[RED].adjustPWMVolume(0);
                        rgbs[GREEN].adjustPWMVolume(0);
                        rgbs[BLUE].adjustPWMVolume(range);
                        break;
                
            case 3:     rgbs[RED].adjustPWMVolume(range);
                        rgbs[GREEN].adjustPWMVolume(range);
                        rgbs[BLUE].adjustPWMVolume(0);
                        break;
                
            case 4:     rgbs[RED].adjustPWMVolume(range);
                        rgbs[GREEN].adjustPWMVolume(0);
                        rgbs[BLUE].adjustPWMVolume(range);
                        break;
                
            case 5:     rgbs[RED].adjustPWMVolume(0);
                        rgbs[GREEN].adjustPWMVolume(range);
                        rgbs[BLUE].adjustPWMVolume(range);
                        break;
                
            case 6:     rgbs[RED].adjustPWMVolume(range);
                        rgbs[GREEN].adjustPWMVolume(range);
                        rgbs[BLUE].adjustPWMVolume(range);
                        break;
                
            case 7:     rgbs[RED].adjustPWMVolume(range);
                        rgbs[GREEN].adjustPWMVolume(0);
                        rgbs[BLUE].adjustPWMVolume(0);
                        break;
                
            default:    break;
        }
    }
    
    @Override
    public void run() {
        while(runSensors) {
            try {
                for (int i=0; i < N_CHANNELS; i++) {
                    read(i);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            averageIndex++;
            if(averageIndex == AV_MAX) {
                for (int i = 0; i < N_CHANNELS; i++) {
                    int valid = 0;
                    double sum = 0;
                    
                    for (int j = 0; j < AV_MAX; j++) {
                        if(tempRanges[i][j] != -1) {
                            valid++;
                            sum+=tempRanges[i][j];
                        }
                    }
                    
                    if(valid == 4) {
                        double rangei = sum/(double)valid;
                        if(rangei <= MAX_RANGE) {
                            ranges[i] = rangei;
                        }
                    } else {
                        ranges[i] = -1;
                    }
                    
                    if(ranges[i] != -1 && musicMode != 0) {
                        //inflag = true;
                        double percentRange = ((int)ranges[i]/MAX_RANGE)*100;
                        adjustLedByPosition(i,(int)percentRange);
                    }
                }
                averageIndex = 0;
                
                try {
                    InetAddress address = InetAddress.getByName("192.168.1.255");
                    String message = String.format("raspi,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%d",(int)ranges[0],(int)ranges[1],(int)ranges[2],(int)ranges[3],(int)ranges[4],(int)ranges[5],(int)ranges[6],(int)ranges[7],BPM,playingSong,musicMode);
                    byte[] messageb = message.getBytes();

                    DatagramPacket packet = new DatagramPacket(messageb, messageb.length,address, udpSendingPort);

                    udpSendingSocket.send(packet);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
