package source;

/**
 *
 * @author silvesterjaksa
 */

import java.awt.Color;

public class Song {
    public String id;
    public String genre;
    public int rythm;					// 1-7 neizrazit/izrazit
    public int tempo;					// 1-7 pocasen/hiter
    public int melodious;				// 1-7 brez melodije/mocna melodija
    public int dynamics;				// 1-7 mehko-tiho/glasno-trdo
    public String BPM;					// beats per minute
    public String mode;					// 1 minor-7 major
    public String harmonic_complexity;	// 1-simple, 7 complex
    public String consonance;			// 1-7 disonantno/konsonantno
    public String metrum;				// 4/4, 3/4 itd
    public Color RGB;


    public Song(String idk, String g, int r, int t, int m, int d, String b, String md, String hc, String c, String mt) {
        this.id = idk;
        this.genre = g;
        this.rythm = r;
        this.tempo = t;
        this.melodious = m;
        this.dynamics = d;
        this.BPM = b;
        this.mode = md;
        this.harmonic_complexity = hc;
        this.consonance = c;
        this.metrum = mt;
    }

    public Song(String idk, String g, int r, int t, int m, int d, String b, String md, String hc, String c, String mt, int red, int green, int blue) {
        this.id = idk;
        this.genre = g;
        this.rythm = r;
        this.tempo = t;
        this.melodious = m;
        this.dynamics = d;
        this.BPM = b;
        this.mode = md;
        this.harmonic_complexity = hc;
        this.consonance = c;
        this.metrum = mt;
        this.RGB = new Color(red,green,blue);
    }

    public void setColor(float hue, float saturation, float brightness) {
        this.RGB = new Color(Color.HSBtoRGB(hue, saturation, brightness));
    }

    public String toString() {
        return String.format("%s  %s  %d  %d  %d  %d  %s  %s  %s  %s  %s  %d  %d  %d", id,genre,rythm,tempo,melodious,dynamics,BPM,mode,harmonic_complexity,consonance,metrum,RGB.getRed(),RGB.getGreen(),RGB.getBlue());
    }
}
