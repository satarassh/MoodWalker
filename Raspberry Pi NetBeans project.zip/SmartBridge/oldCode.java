String filename = getCurrentDate()+"-"+getCurrentTime(true);

                String path = dataDir+filename+".txt";
                File file = new File(path);
                FileWriter output = new FileWriter(file, true);

                try {
                    PrintWriter writer = new PrintWriter(output);
                    writer.println(c.email);
                    writer.println("samples "+c.temporaryDataProximity.size());
                    writer.println(String.format("seconds %.1f",centis));
                    writer.println("VA "+c.temporaryDataVaX+" "+c.temporaryDataVaY);
                    
                    int ind = 1;
                    for(ProximityData d : c.temporaryDataProximity) {
                        writer.print(ind+": "+d);
                        ind++;
                    }
                    
                    writer.print("\n");
                    
                    ind = 1;
                    for(GyroscopeData d : c.temporaryDataGyroscope) {
                        writer.print(ind+": "+d);
                        ind++;
                    }

                    writer.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    okIndicatorTimer.stop();
                    OK_indicator.setState(PinState.LOW);
                }
                
                
/*
            if(!inflag) {
                rgbs[RED].adjustPWMVolume(0);
                rgbs[GREEN].adjustPWMVolume(0);
                rgbs[BLUE].adjustPWMVolume(0);
            }

            try {
                InetAddress address = InetAddress.getByName("192.168.1.255");
                String message = String.format("raspi,%d,%d,%d,%d,%d,%d,%d,%d",(int)ranges[0],(int)ranges[1],(int)ranges[2],(int)ranges[3],(int)ranges[4],(int)ranges[5],(int)ranges[6],(int)ranges[7]);
                byte[] messageb = message.getBytes();

                DatagramPacket packet = new DatagramPacket(messageb, messageb.length,address, udpPort);

                udpSocket.send(packet);

                System.out.println("raspi,"+message);
            } catch (Exception e) {
                e.printStackTrace();
            }
            */
            
            
package source;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetChangeListener;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.AbstractXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;


public class TranslateDemo1 extends ApplicationFrame {
	private static class MyDemoPanel extends DemoPanel implements ChangeListener {
		static class TranslatingXYDataset extends AbstractXYDataset implements XYDataset, DatasetChangeListener {

			private XYDataset underlying;
			private double translate;

			public double getTranslate()
			{
				return translate;
			}

			public void setTranslate(double d)
			{
				translate = d;
				fireDatasetChanged();
			}

			public int getItemCount(int i)
			{
				return underlying.getItemCount(i);
			}

			public double getXValue(int i, int j)
			{
				return underlying.getXValue(i, j) + translate;
			}

			public Number getX(int i, int j)
			{
				return new Double(getXValue(i, j));
			}

			public Number getY(int i, int j)
			{
				return new Double(getYValue(i, j));
			}

			public double getYValue(int i, int j)
			{
				return underlying.getYValue(i, j);
			}

			public int getSeriesCount()
			{
				return underlying.getSeriesCount();
			}

			public Comparable getSeriesKey(int i)
			{
				return underlying.getSeriesKey(i);
			}

			public void datasetChanged(DatasetChangeEvent datasetchangeevent)
			{
				fireDatasetChanged();
			}

			public TranslatingXYDataset(XYDataset xydataset)
			{
				underlying = xydataset;
				underlying.addChangeListener(this);
				translate = 0.0D;
			}
		}


		private TimeSeries series_x, series_y, series_z;
		private ChartPanel chartPanel;
		private JFreeChart chart;
		private TranslatingXYDataset dataset_x, dataset_y, dataset_z;
		
		// JDBC driver name and database URL
	    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	    static final String DB_URL = "jdbc:mysql://192.168.1.172:3306/diploma";
	    //static final String DB_URL = "jdbc:mysql://localhost/diploma";

	    //  Database credentials
	    static final String USER = "root";
	    //static final String USER = "silvester";
	    static final String PASS = "jaksa";

		private JFreeChart createChart(XYDataset ds, String title) {
			JFreeChart jfreechart = ChartFactory.createTimeSeriesChart(title, "Time", "Value", ds, false, false, false);
			XYPlot xyplot = (XYPlot)jfreechart.getPlot();
			xyplot.setOrientation(PlotOrientation.VERTICAL);
			xyplot.setDomainCrosshairVisible(true);
			xyplot.setDomainCrosshairLockedOnData(false);
			xyplot.setRangeCrosshairVisible(false);
			DateAxis dateaxis = (DateAxis)xyplot.getDomainAxis();
			org.jfree.data.Range range = DatasetUtilities.findDomainBounds(ds);
			dateaxis.setRange(range);
			dateaxis.setVisible(false);
			return jfreechart;
		}

		private void createDatasets(RegularTimePeriod regulartimeperiod) {
			series_x = new TimeSeries("Acc X");
			series_y = new TimeSeries("Acc Y");
			series_z = new TimeSeries("Acc Z");
			RegularTimePeriod regulartimeperiod1 = regulartimeperiod;
			Connection conn = null;
			Statement stmt = null;
			
			try {
		      Class.forName("com.mysql.jdbc.Driver");
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);
		
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String sql;
		      //sql = "SELECT * FROM sensors WHERE acquire_info_id=60 AND (ps1<>-1 OR ps2<>-1 OR ps3<>-1 OR ps4<>-1 OR ps5<>-1 OR ps6<>-1 OR ps7<>-1 OR ps8<>-1)";
		      sql = "SELECT * FROM sensors WHERE acquire_info_id=60";
		      ResultSet rs = stmt.executeQuery(sql);
		      
		      int fulls = 0;
		      int empties = 0;
		      
		      while(rs.next()) {
		    	 int ps1 = rs.getInt("ps1");
		    	 int ps2 = rs.getInt("ps2");
		    	 int ps3 = rs.getInt("ps3");
		    	 int ps4 = rs.getInt("ps4");
		    	 int ps5 = rs.getInt("ps5");
		    	 int ps6 = rs.getInt("ps6");
		    	 int ps7 = rs.getInt("ps7");
		    	 int ps8 = rs.getInt("ps8");
		         //float gsx = rs.getFloat("gsx");
		         //float gsy = rs.getFloat("gsy");
		         //float gsz = rs.getFloat("gsz");
		         
		         if(ps1==-1 && ps2==-1 && ps3==-1 && ps4==-1 && ps5==-1 && ps6==-1 && ps7==-1 && ps8==-1) {
		        	 empties++;
		        	 fulls=0;
		         } else {
		        	 fulls++;
		        	 empties=0;
		         }
		         
		         if(fulls==5) {
		        	 for (int i = 0; i < 5; i++) {
						rs.previous();
					 }
		        	 
		        	 float gsx = rs.getFloat("gsx");
			         float gsy = rs.getFloat("gsy");
			         float gsz = rs.getFloat("gsz");
			         
		        	 series_x.add(regulartimeperiod1, gsx);
			         series_y.add(regulartimeperiod1, gsy);
			         series_z.add(regulartimeperiod1, gsz);
			         regulartimeperiod1 = regulartimeperiod1.next();
			         
			         rs.next();
			         
			         gsx = rs.getFloat("gsx");
			         gsy = rs.getFloat("gsy");
			         gsz = rs.getFloat("gsz");
			         
		        	 series_x.add(regulartimeperiod1, gsx);
			         series_y.add(regulartimeperiod1, gsy);
			         series_z.add(regulartimeperiod1, gsz);
			         regulartimeperiod1 = regulartimeperiod1.next();
			         
			         rs.next();
			         
			         gsx = rs.getFloat("gsx");
			         gsy = rs.getFloat("gsy");
			         gsz = rs.getFloat("gsz");
			         
		        	 series_x.add(regulartimeperiod1, gsx);
			         series_y.add(regulartimeperiod1, gsy);
			         series_z.add(regulartimeperiod1, gsz);
			         regulartimeperiod1 = regulartimeperiod1.next();
			         
			         rs.next();
			         
			         gsx = rs.getFloat("gsx");
			         gsy = rs.getFloat("gsy");
			         gsz = rs.getFloat("gsz");
			         
		        	 series_x.add(regulartimeperiod1, gsx);
			         series_y.add(regulartimeperiod1, gsy);
			         series_z.add(regulartimeperiod1, gsz);
			         regulartimeperiod1 = regulartimeperiod1.next();
			         
			         rs.next();
			         
			         gsx = rs.getFloat("gsx");
			         gsy = rs.getFloat("gsy");
			         gsz = rs.getFloat("gsz");
			         
		        	 series_x.add(regulartimeperiod1, gsx);
			         series_y.add(regulartimeperiod1, gsy);
			         series_z.add(regulartimeperiod1, gsz);
		         } else if(fulls > 5){
		        	 float gsx = rs.getFloat("gsx");
			         float gsy = rs.getFloat("gsy");
			         float gsz = rs.getFloat("gsz");
			         
		        	 series_x.add(regulartimeperiod1, gsx);
			         series_y.add(regulartimeperiod1, gsy);
			         series_z.add(regulartimeperiod1, gsz);
		         } else {
		        	 series_x.add(regulartimeperiod1, 0);
			         series_y.add(regulartimeperiod1, 0);
			         series_z.add(regulartimeperiod1, 0);
		         }
		         
				 regulartimeperiod1 = regulartimeperiod1.next();
		      }
		      rs.close();
		      stmt.close();
		      conn.close();
		   }catch(SQLException se){
		      se.printStackTrace();
		   }catch(Exception e){
		      e.printStackTrace();
		   }finally{
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		   }
			
			System.out.println("Fetching successful!");

			TimeSeriesCollection tscx = new TimeSeriesCollection();
			tscx.addSeries(series_x);
			dataset_x = new TranslatingXYDataset(tscx);
			
			TimeSeriesCollection tscy = new TimeSeriesCollection();
			tscy.addSeries(series_y);
			dataset_y = new TranslatingXYDataset(tscy);
			
			TimeSeriesCollection tscz = new TimeSeriesCollection();
			tscz.addSeries(series_z);
			dataset_z = new TranslatingXYDataset(tscz);
		}
		
		public void stateChanged(ChangeEvent changeevent) {
			System.out.println();
		}

		public MyDemoPanel(int mode) {
			super(new BorderLayout());
			createDatasets(new Second());
			
			if(mode==1) {
				chart = createChart(dataset_x, "Accelerometer X");
				addChart(chart);
				chartPanel = new ChartPanel(chart);
				chartPanel.setPreferredSize(new Dimension(600, 270));
				chartPanel.setDomainZoomable(true);
				chartPanel.setRangeZoomable(true);
				javax.swing.border.CompoundBorder compoundborder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createEtchedBorder());
				chartPanel.setBorder(compoundborder);
				add(chartPanel);
			} else if(mode==2) {
				chart = createChart(dataset_y, "Accelerometer Y");
				addChart(chart);
				chartPanel = new ChartPanel(chart);
				chartPanel.setPreferredSize(new Dimension(600, 270));
				chartPanel.setDomainZoomable(true);
				chartPanel.setRangeZoomable(true);
				javax.swing.border.CompoundBorder compoundborder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createEtchedBorder());
				chartPanel.setBorder(compoundborder);
				add(chartPanel);
			} else if(mode==3) {
				chart = createChart(dataset_z, "Accelerometer Z");
				addChart(chart);
				chartPanel = new ChartPanel(chart);
				chartPanel.setPreferredSize(new Dimension(600, 270));
				chartPanel.setDomainZoomable(true);
				chartPanel.setRangeZoomable(true);
				javax.swing.border.CompoundBorder compoundborder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createEtchedBorder());
				chartPanel.setBorder(compoundborder);
				add(chartPanel);
			}
			
			JPanel jpanel = new JPanel(new BorderLayout());
			jpanel.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
			add(jpanel, "South");
		}
	}


	public TranslateDemo1(String s, int mode)
	{
		super(s);
		setContentPane(new MyDemoPanel(mode));
	}

	public static void main(String args[])
	{
		TranslateDemo1 td1x = new TranslateDemo1("Accelerometer X", 1);
		td1x.pack();
		RefineryUtilities.centerFrameOnScreen(td1x);
		td1x.setVisible(true);
		
		TranslateDemo1 td1y = new TranslateDemo1("Accelerometer Y", 2);
		td1y.pack();
		RefineryUtilities.centerFrameOnScreen(td1y);
		td1y.setVisible(true);
		
		TranslateDemo1 td1z = new TranslateDemo1("Accelerometer Z", 3);
		td1z.pack();
		RefineryUtilities.centerFrameOnScreen(td1z);
		td1z.setVisible(true);
	}
}